import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';

@Injectable({
	providedIn: 'root'
})
export class AuthInterceptorService implements HttpInterceptor {

	constructor() { }

	intercept(req: HttpRequest<any>, next: HttpHandler) {

		if (sessionStorage.getItem('id') && sessionStorage.getItem('token')) {
			req = req.clone({
				setHeaders: {
					'id': sessionStorage.getItem('id') as string,
					'token': sessionStorage.getItem('token') as string,
					'Content-Type': 'application/json'
				}
			});
		}

		console.log('Header added');

		return next.handle(req);
	}
}