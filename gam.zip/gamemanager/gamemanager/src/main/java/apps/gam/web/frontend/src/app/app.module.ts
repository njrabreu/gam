import { NgModule } from '@angular/core';

import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { GameService } from './services/game.service';
import { AuthInterceptorService } from './services/auth-interceptor.service';

import { AppComponent } from './app.component';
import { GameComponent } from './components/game/game.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { ErrorpageComponent } from './components/errorpage/errorpage.component';

@NgModule({
	declarations: [
		AppComponent,
		GameComponent,
		HomeComponent,
		LoginComponent,
  ErrorpageComponent
	],
	imports: [
		BrowserModule,
		AppRoutingModule,
		HttpClientModule,
		ReactiveFormsModule
	],
	providers: [GameService, DatePipe,
		{
			provide: HTTP_INTERCEPTORS, useClass: AuthInterceptorService, multi: true
		}],
	bootstrap: [AppComponent]
})
export class AppModule { }
