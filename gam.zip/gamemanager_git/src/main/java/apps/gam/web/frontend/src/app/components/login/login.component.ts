import { Component, OnInit } from '@angular/core';
import { GameService } from '../../services/game.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
	selector: 'app-home',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

	user: string = "";
	validMessage: string = "";

	loginform: FormGroup =
		new FormGroup({
			login: new FormControl('', Validators.required),
			password: new FormControl('', Validators.required)
		});

	constructor(private gameService: GameService, private router: Router) { }

	ngOnInit(): void {

	}

	proceedWithLogin() {

		console.log(this.user);

		if (this.user.includes(this.loginform.controls['login'].value)) {
			this.validMessage = "Login OK!";
			this.router.navigateByUrl('/allgames');
		}
		else {
			this.validMessage = "Invalid login!";
		}
	}

	tryLogin() {

		this.gameService.checkUser(this.loginform.controls['login'].value, this.loginform.controls['password'].value).subscribe(
			data => { this.user = (data as any).id; this.proceedWithLogin(); },
			err => console.error(err),
			() => { console.log("tryLogin: answer complete!") }
		);
	}

	registerLogin() {

		this.gameService.registerUser(this.loginform.controls['login'].value, this.loginform.controls['password'].value).subscribe(
			data => { this.validMessage = "User registered!"; },
			err => console.error(err),
			() => { console.log("registerLogin: answer complete!") }
		);
	}
}
