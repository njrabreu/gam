import { Component, OnInit } from '@angular/core';
import { GameService } from '../../services/game.service';
import { Router } from '@angular/router';

@Component({
	selector: 'app-game',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

	public allgames: any;
	currentUser: string = "";

	constructor(private gameService: GameService, private router: Router) { }

	ngOnInit(): void {
		this.getAllGames();
		this.currentUser = this.gameService.getCurrentUser();

		if (this.currentUser === "") {
			console.log("User not authenticated. Redirecting to login page...");
			this.router.navigateByUrl('/');
		}
	}

	getAllGames() {
		this.gameService.getAllGames().subscribe(
			data => { this.allgames = data },
			err => console.error(err),
			() => console.log('All Games Loaded!')
		);
	}
}
