import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
	headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
	providedIn: 'root'
})
export class GameService {

	private currentUser: string = "";

	constructor(private http: HttpClient) { }

	getCurrentUser() {
		return this.currentUser;
	}

	getAllGames() {
		return this.http.get('server/game/all');
	}

	getPlatforms() {
		return this.http.get('server/game/platforms');
	}

	getRates() {
		return this.http.get('server/game/rates');
	}

	getStatuses() {
		return this.http.get('server/game/statuses');
	}

	getGame(id: number) {
		return this.http.get('server/game/' + id);
	}

	createGameRegistration(game: any) {
		let body = game;
		return this.http.post('server/game/new', body, httpOptions);
	}

	updateGameRegistration(game: any) {
		let body = game;
		return this.http.post('server/game/update', body, httpOptions);
	}

	checkUser(id: string, pwd: string) {
		let url = 'server/user/check?id=' + id + "&pwd=" + pwd;
		this.currentUser = id;
		return this.http.get(url);
	}

	registerUser(id: string, pwd: string) {
		let url = 'server/user/register?id=' + id + "&pwd=" + pwd;
		return this.http.post(url, null, httpOptions);
	}
}
