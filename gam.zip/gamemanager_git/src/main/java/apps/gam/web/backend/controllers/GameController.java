package apps.gam.web.backend.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import apps.gam.desktop.core.MyLogger;
import apps.gam.web.backend.models.All_Games;
import apps.gam.web.backend.models.Game;
import apps.gam.web.backend.repositories.AllGamesRepository;
import apps.gam.web.backend.repositories.GameRepository;
import apps.gam.web.backend.repositories.PlatformRepository;
import apps.gam.web.backend.repositories.RateRepository;
import apps.gam.web.backend.repositories.StatusRepository;

@RestController
@RequestMapping("/game")
public class GameController {
	@Autowired
	private AllGamesRepository allGamesRepository;
	@Autowired
	private GameRepository gameRepository;
	@Autowired
	private PlatformRepository platformRepository;
	@Autowired
	private RateRepository rateRepository;
	@Autowired
	private StatusRepository statusRepository;

	@GetMapping("/all")
	public List<All_Games> list() {
		MyLogger.WriteMessage("Showing all games via web!");
		return allGamesRepository.findAll();
	}

	@GetMapping("/{id}")
	public Game get(@PathVariable("id") int id) {
		MyLogger.WriteMessage("Showing game ID " + id + " via web!");
		return gameRepository.getById(id);
	}
	
	@GetMapping("/platforms")
	public String platforms() {
		MyLogger.WriteMessage("Showing all platforms via web!");
		return new Gson().toJson(platformRepository.getPlatforms());
	}
	
	@GetMapping("/rates")
	public String rates() {
		MyLogger.WriteMessage("Showing all rates via web!");
		return new Gson().toJson(rateRepository.getRates());
	}

	@GetMapping("/statuses")
	public String statuses() {
		MyLogger.WriteMessage("Showing all statuses via web!");
		return new Gson().toJson(statusRepository.getStatuses());
	}

	@PostMapping("/new")
	@ResponseStatus(HttpStatus.OK)
	public void create(@RequestBody Game g) {
		MyLogger.WriteMessage("Registering game " + g.getId() + " via web!");
		gameRepository.save(g);
	}
	
	@PostMapping("/update")
	@ResponseStatus(HttpStatus.OK)
	public void update(@RequestBody Game g) {
		MyLogger.WriteMessage("Updating game " + g.getId() + " via web!");
		gameRepository.updateGame(g.getId(), g.getTitle(), g.getCompletion(), g.getPlatform(), g.getRate(), g.getStatus());
	}
}
